---
title: Kuwait Towers
date: 2015-02-25
thumbnail: thumbnail.png
link_to: portfolio-item
layout: portfolio-item
category: Design &amp; Development
images:
  - maxresdefault.jpg
  - download.png
  - download (1).png
  - download (2).png
  - download (3).png
  - download (4).png
  - IMG_20150111_114737.jpg
  - IMG_20150111_115322.jpg
herovimeoid:
videos:
  - 288094924
  - 288094943
  - 288094965
  - 288094996
description: 
dates: Feburary 25th, 2015
location: Kuwait City, Kuwait
role: Software Director
link:
linktext:
collaborators:
  - Obscura Digital
  - Khabari International
---
