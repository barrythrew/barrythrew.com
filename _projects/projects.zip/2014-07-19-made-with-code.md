---
title: Made with Code
date: 2014-07-19
thumbnail: thumbnail.png
link_to: portfolio-item
layout: portfolio-item
category: Design & Development
images:
  - Seth_Mach_Presentation_Page_37_s.jpg
  - Seth_Mach_Presentation_Page_32_s.jpg
  - Seth_Mach_Presentation_Page_28_s.jpg
  - Seth_Mach_Presentation_Page_27_s.jpg
  - F21A7273_670_s.jpg
  - F21A7218_670_s.jpg
  - F21A7197_670_s.jpg
  - F21A7062_670_s.jpg
  - F21A7048_670_s.jpg
  - F21A6769_670_s.jpg
  - 260C7876_670_s.jpg
  - 260C7860_670_s.jpg
herovimeoid:
videos:
  - 175252428
  - 127753056
description: An initiative launched by Google to empower young women in middle and high schools with computer programming skills. 
dates: July 19th, 2014
location: New York, New York
role: Software Director, Obscura
link: https://www.madewithcode.com/
linktext: Made with Code
collaborators:
  - Obscura Digital
  - Red&Co
---
