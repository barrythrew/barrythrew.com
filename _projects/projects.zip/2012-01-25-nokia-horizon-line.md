---
title: Nokia Horizon Line
date: 2012-01-25
thumbnail: thumbnail.png
link_to: portfolio-item
layout: portfolio-item
category: Design & Development
images:
  - IMG_1673.JPG_s.jpg
  - IMG_1654.JPG_s.jpg
  - IMG_1627.JPG_s.jpg
  - IMG_1622.JPG_s.jpg
  - IMG_1613.JPG_s.jpg
  - IMG_1603.JPG_s.jpg
herovimeoid:
videos: 
  - 291432661
description: 
dates: 2012
location: Nokia R&D, Sunnyvale, CA
role: Developer
link: 
linktext: 
collaborators:
  - Obscura Digital
  - Scott Pagano
  - James Hurlbut
---
