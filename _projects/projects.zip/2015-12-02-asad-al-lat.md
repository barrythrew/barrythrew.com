---
title: Asad al-Lat
date: 2015-12-02
thumbnail: thumbnail.png
link_to: portfolio-item
layout: portfolio-item
category: Curation &amp; Production
images:
  - asad-al-lat-hires-2.png_s.jpg
  - asad-al-lat-hires-1.png_s.jpg
  - asad-al-lat-3d-modeling-screenshot_s.jpg
herovimeoid:
videos:
description: 
dates: 2015
location: Virtual
role: Director
link:
linktext:
collaborators:
  - "#NEWPALMYRA"
  - Georges Dahdouh
---
The Asad Al-Lat statue was destroyed by Daesh terrorists in the ancient city of Palmyra, Syria along with most of the main world heritage ruins in the city.

This 3d model was reconstructed by the #NEWPALMYRA project, and relased into the Public Domain to be freely downloadable by everyone.