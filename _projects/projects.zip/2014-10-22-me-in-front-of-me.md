---
title: Me In Front of Me
date: 2014-10-22
thumbnail: thumbnail.png 
link_to: portfolio-item
layout: portfolio-item
category: Design &amp; Development
images:
  - IMG_5573.jpg
  - IMG_5576.jpg
  - IMG_5577.jpg
  - IMG_5592.jpg
  - IMG_5598.jpg
  - IMG_5609.jpg
  - IMG_5758.jpg
  - IMG_5805.jpg
  - IMG_5927.jpg
  - IMG_6019.jpg
  - IMG_6078.jpg
  - IMG_6099.jpg
  - IMG_6108.jpg
herovimeoid:
videos:
  - 285921747
  - 285921629
description: Theatrical performance with real time control of projection-mapped animations.
dates: 2014
location: Caen, France
role: Lead Developer
link:
linktext:
collaborators:
  - FuturePerfect Productions
  - Comedie de Caen
---
