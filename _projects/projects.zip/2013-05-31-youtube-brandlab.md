---
title: YouTube BrandLab
date: 2013-05-31
thumbnail: thumbnail.png
link_to: portfolio-item
layout: portfolio-item
category: Design & Development
images:
  - BrandLab_Blog.JPG_s.jpg
  - 12804657504_c7de0fcf51_b_s.jpg
  - tsla01_s.jpg
  - nvidia02_cc_s.jpg
  - image_s.jpg
  - image(1)_s.jpg
  - brandlab-2_orig_s.jpg
  - brandlab-1_orig_s.jpg
  - 11260833_107496906254879_1541266834_n_s.jpg
herovimeoid:
videos:
description: Multi-installation experiential space for workshops and client education.
dates: 2013
location: YouTube Headquarters, San Bruno, CA
role: Software Director
link: 
linktext: 
collaborators:
  - Obscura Digital
---
