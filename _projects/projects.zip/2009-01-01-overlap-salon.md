---
title: Overlap Salons
date: 2009-01-01
thumbnail: thumb.png
link_to: portfolio-item
layout: portfolio-item
category: Curation &amp; Production
images:
  - olsalon1.jpeg
  - olsalon2.jpeg
  - olsalon3.jpeg
  - olsalon4.jpeg
  - olsalon5.jpg
herovimeoid:
description: Educational salons and sharing events.
dates: 2009
location: San Francisco, CA
role: Organizer
collaborators:
  - Christopher Willitz
  - Vlad Spears
  - Jon Phillips
---
