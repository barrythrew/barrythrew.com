---
title: Palmyrene Column
date: 2016-06-13
thumbnail: thumbnail.png
link_to: portfolio-item
layout: portfolio-item
category: Curation &amp; Production
images:
  - IMG_20160527_182434_s.jpg
  - IMG_20160527_182231_s.jpg
herovimeoid:
videos:
description: Reproduction of a column pediment from Palmyra Syria, displayed at the World of Fragile Parts exhibition at the 2016 Venice Biennale.
dates: 2016
location: Venice, IT
role: Director
link:
linktext:
collaborators:
  - Bassel Khartabil
  - Jim Ellis
  - Annie Schneider
  - Brenden Cormier
---
