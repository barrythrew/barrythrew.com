---
title: Pixeltree
date: 2014-08-01
thumbnail: thumbnail.png
link_to: portfolio-item
layout: portfolio-item
category: Design &amp; Development
images:
  - 260C9850_-Web.jpg
  - 260C9858_-Web.jpg
  - 260C9890_-Web.jpg
  - 260C9976_-Web.jpg
  - 260C9988_-Web.jpg
  - googlepixeltree_dsc_0036m2-1600x1068.jpg
  - googlepixeltree_dsc_0042m2-1600x1068.jpg
  - googlepixeltree_dsc_0094m2-1600x1068.jpg
  - googlepixeltree_googleplex-1600x1061.jpg
herovimeoid:
videos:
description: Interactive installation built from networked devices.
dates: 2014
location: Google Campus, Mountainview, CA
role: Software Director
link:
linktext:
collaborators:
  - Obscura Digital
  - IwamotoScott Architecture
  - Google
---
