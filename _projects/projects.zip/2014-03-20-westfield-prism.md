---
title: Westfield Prism
date: 2014-03-20
thumbnail: thumbnail.png
link_to: portfolio-item
layout: portfolio-item
category: Design &amp; Development
images:
  - 3D+Mockup.jpg
  - 1326413_Westfield-Labs-digital-kiosk.jpg
  - Good_Angle_Prism_2.jpg
  - Good_Angle_Prism_3.jpg
  - Good_Angle_Prism_5.jpg
  - Good_Angle_Prism_6+2.jpg
  - Seth_Mach_Presentation_Page_05.jpg
  - westfield_digitalstorefront_1.jpeg
herovimeoid:
videos:
  - 285037513
description: Interactive, scalable kiosk platform for advertizing and entertainment. 
dates: 2014
location: Westfield Garden State Plaza Mall, Jersey City, NJ
role: Software Director
link:
linktext:
collaborators:
  - Obscura Digital
  - Westfield Labs
---
