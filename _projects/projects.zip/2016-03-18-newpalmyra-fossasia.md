---
title: "#NEWPALMYRA at FOSSASIA Singapore"
date: 2016-03-18
thumbnail: thumbnail.png
link_to: portfolio-item
layout: portfolio-item
category: Curation &amp; Production
images:
  - fossasia-06_s.jpg
  - fossasia-05_s.jpg
  - fossasia-04_s.jpg
  - fossasia-03_s.jpg
  - fossasia-02_s.jpg
  - fossasia-01_s.jpg
  - fossasia-00_s.jpg
herovimeoid:
videos:
  - 172544085
  - 289208259
description: Cultural heritage workshop and collaborative art project.
dates: March 18-20th, 2016
location: Singapore
role: Director
link:
linktext:
collaborators:
  - FOSSAsia
  - Jon Phillips
  - Annie Schneider
---
